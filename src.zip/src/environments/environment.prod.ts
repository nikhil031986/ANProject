export const environment = {
  production: false,
  APIUrl:  "https://localhost:7269/api/",
  APIHost:"https://localhost:7269/",
  stripKey:"pk_test_51QMXyVQZ6Kd2u4hz4cYiiXRYyEe22iAg3oBKUqEf53RadIReeR93RBX6Ci20OKRlk0XqLFypxtKdJ0NvZzUs4lVp00p8xeXsWH",
  isdirectsec:false,
  iskyraden:true,
};