import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-itemcatwise',
  templateUrl: './itemcatwise.component.html',
  styleUrls: ['./itemcatwise.component.css']
})
export class ItemcatwiseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
