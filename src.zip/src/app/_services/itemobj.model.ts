export interface Itemobj {
        itemCode:string
        itemdes:string
        qty:Number
        imgpath:string
        itemprice:number
}
