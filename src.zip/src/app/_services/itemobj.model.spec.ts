import { Itemobj } from './itemobj.model';

describe('Itemobj', () => {
  it('should create an instance', () => {
    expect(new Itemobj()).toBeTruthy();
  });
});
